angka = [1,2,3,4,5]
kata = ["satu", "dua", "tiga", "empat", "lima"]
campuran = [1, "dua", 3.0, "empat", 5]

print(angka[0])

angka[2] = 6
print(angka)
