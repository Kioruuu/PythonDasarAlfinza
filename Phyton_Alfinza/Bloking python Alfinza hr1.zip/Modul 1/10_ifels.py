x = 10
if x > 5:
    print("x lebih besar  dari 5")
else:
    print("x tidak lebih besar dari 5")