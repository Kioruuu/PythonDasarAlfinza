for x in [1,2,3,4,5]:
    if x == 3:
        continue
    print(x)