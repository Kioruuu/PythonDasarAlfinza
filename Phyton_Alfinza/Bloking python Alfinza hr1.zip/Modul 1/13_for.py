for x in ["apel", "jeruk", "pisang"]:
    print(x)