x = 5 == 5
y = 1 > 2

print('x and y is',x and y)
print('x or y is', x or y )
print('not x is',not x)