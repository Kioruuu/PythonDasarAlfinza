x=10
if x > 10:
    print("x lebih besar dari 10")
elif x < 10:
    print("x lebih kecl dari 10")
else:
    print("x sama dengan 10")