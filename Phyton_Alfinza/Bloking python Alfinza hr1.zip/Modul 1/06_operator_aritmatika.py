a = 10
b = 2

print ("tambah \t\t : ", a + b)
print ("kurang \t\t : ", a - b)
print ("kali \t\t : ", a * b)
print ("bagi \t\t : ", a / b)
print ("mod \t\t : ", b % a)
print ("pangkat \t\t : ", a ** b)
print ("pembagian \t\t : ", b // a)