x = "John"

x = 'John'

a = 4
A = "Sally"

print(x)
print(a)
print(A)
