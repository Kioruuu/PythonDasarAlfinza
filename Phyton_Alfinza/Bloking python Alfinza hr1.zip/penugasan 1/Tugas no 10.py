for i in range(1, 101):
  print("Saya tidak akan mengulangi perbuatan itu lagi")