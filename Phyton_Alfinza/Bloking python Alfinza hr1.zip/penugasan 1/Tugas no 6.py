nilai = int(input("Masukkan nilai siswa: "))

if nilai > 75: 
    print("Selamat, Anda tidak perlu mengulang kelas!")
else:
    print("Maaf, Anda harus mengulang kelas!")