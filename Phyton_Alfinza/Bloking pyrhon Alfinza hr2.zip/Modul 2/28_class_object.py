class Myclass:
    x = 5

p1 = Myclass()
print(p1.x)