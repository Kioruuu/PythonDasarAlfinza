def my_function(fname):
    print(fname + " Refsnes")

my_function("Emil")
my_function("tobias")
my_function("Linus")